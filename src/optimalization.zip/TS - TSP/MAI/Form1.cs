﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MAI
{
    public partial class Form1 : Form
    {
        int bound;
        int boundRight;
        int pocetOhodnoteni;
        int noOfDimensions;
        int pocetSusedov;
        double percentPriestoru;
        int maxTeplota;
        int minTeplota;
        string patch;
        string tspPatch;
        FileStream fileStream;
        byte[] bytes;
        public Form1()
        {

            InitializeComponent();
            bound = (int)numericHranicaZlava.Value;
            pocetOhodnoteni = (int)numericFES.Value;
            noOfDimensions = 2;
            pocetSusedov = (int)numericPocetSusedov.Value;
            percentPriestoru = (double)numericPercentPriestoru.Value / 100;
            maxTeplota = (int)numericMaxT.Value;
            minTeplota = (int)numericMinT.Value;
            patch = textPatch.Text;
            try
            {
                fileStream = new FileStream(@"TSPpatch.bin", FileMode.Open);
                bytes = ReadFully(fileStream);
                tspPatch = DeserializeFromBytes(bytes);
                fileStream.Close();
                textTSP.Text = tspPatch;

            }
            catch (Exception e)
            {
                textTSP.Text = @"d:\something.xml";
       //         fileStream.Close();
            }

        }
        public static byte[] ReadFully(Stream input)
        {
            byte[] buffer = new byte[16 * 1024];
            using (MemoryStream ms = new MemoryStream())
            {
                int read;
                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }
                return ms.ToArray();
            }
        }

        public static byte[] SerializeToBytes<T>(T item)
        {
            var formatter = new BinaryFormatter();
            using (var stream = new MemoryStream())
            {
                formatter.Serialize(stream, item);
                stream.Seek(0, SeekOrigin.Begin);
                return stream.ToArray();
            }
        }
        public static string DeserializeFromBytes(byte[] bytes)
        {
            var formatter = new BinaryFormatter();
            using (var stream = new MemoryStream(bytes))
            {
                return (string)formatter.Deserialize(stream);
            }
        }

        private void TableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SplitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SplitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }


        private async void ButtonVypocet_ClickAsync(object sender, EventArgs e)
        {
            var checkedRadio = new[] { groupBox1 }
                    .SelectMany(g => g.Controls.OfType<RadioButton>()
                                             .Where(r => r.Checked));
            string search = "";
            string test = "";
            foreach (var c in checkedRadio)
            {
                search = c.Name;
            }
            checkedRadio = new[] { groupBox2 }
                  .SelectMany(g => g.Controls.OfType<RadioButton>()
                                           .Where(r => r.Checked));
            foreach (var c in checkedRadio)
            {
                test = c.Name;
            }
            toolStripStatusLabel1.Text = "calculating...";
            tspPatch = textTSP.Text;


            fileStream = new FileStream(@"TSPpatch.bin", FileMode.Create);
            BinaryWriter writer = new BinaryWriter(fileStream);
            byte[] bytes = SerializeToBytes(tspPatch);
            writer.Write(bytes);
            writer.Close();

            var progress = new Progress<string>(s => toolStripStatusLabel1.Text = s);
            await Task.Factory.StartNew(() => SecondThreadConcern.LongWork(progress, (int)numericHranicaZlava.Value,
                (int)numericFES.Value, (int)numericPocetSusedov.Value, (double)numericPercentPriestoru.Value / 100,
                search, test, (int)numericMinT.Value, (int)numericMaxT.Value, textPatch.Text, tspPatch),
                                        TaskCreationOptions.LongRunning);
          //  toolStripStatusLabel1.Text = "completed";
        }

        private void NumericNoOfDimensions_ValueChanged(object sender, EventArgs e)
        {

        }

        private void TableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }
    }
    class SecondThreadConcern
    {
        public static void LongWork(IProgress<string> progress, int bound,
            int pocetOhodnoteni, int pocetSusedov, double percentPriestoru,
            string search, string test, int Tf, int T0, string patch, string TSPpatch)
        {
            // Perform a long running work...
            progress.Report("calculating...." +
                "");
            Search rs = new Search(bound, pocetOhodnoteni, pocetSusedov,
               percentPriestoru, search, test, Tf, T0, patch, TSPpatch);
            rs.rataj();
            progress.Report("calculated: "+rs.calcTime().ToString());
        }
    }
}
