﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
using System.Collections.Concurrent;

namespace MAI
{
    class Search
    {
        List<List<double>> zapisDoCSV = new List<List<double>>();
        List<List<double>> zapisDoCSVbest = new List<List<double>>();
        double boundLeft;
        double boundRight;
        double pocetOhodnoteni;
        int pocetDimenzii = 2;
        string search;
        string test;
        int pocetSusedov;
        double PercentPriestoru;
        Random random = new Random();
        Test testFunction;
        double T0;
        double Tf;
        int overall = 0;
        string patch;
        TSinstance TSinstance;
        string TSPpatch;
        DateTime start;
        public Search(int Bound, int PocetOhodnoteni, int PocetSusedov,
            double _PercentPriestoru, string Search, string Test, int _Tf, int _T0, string Patch, string _TSPpatch)
        {
            boundLeft = Bound * -1;
            boundRight = Bound;
            pocetOhodnoteni = PocetOhodnoteni;
            search = Search;
            test = Test;
            pocetSusedov = PocetSusedov;
            PercentPriestoru = _PercentPriestoru;
            Tf = _Tf;
            T0 = _T0;
            patch = Patch;
            TSPpatch = _TSPpatch;
            start = DateTime.UtcNow;
        }
        public void rataj()
        {

            testFunction = new Test(test);
            for (int i = 0; i < 30; i++)
            {
                switch (search)
                {
                    case "radioRandom":
                        RandomSearch();
                        break;
                    case "radioLocal":
                        LocalSearch();
                        break;
                    case "radioHill":
                        StochastickHC();
                        break;
                    case "radioZihanie":
                        SA();
                        break;
                    case "radioTabu":
                        TabuSearch();
                        break;
                    default:
                        break;
                }
                overall++;
            }

        }
        public void RandomSearch()
        {

            List<double> arrayVhodnost = new List<double>();
            List<double> arg;
            double vhodnost = getVhodnost();

            for (int i = 0; i < pocetOhodnoteni; i++)
            {
                arg = new List<double>();
                for (int j = 0; j < pocetDimenzii; j++)
                {
                    arg.Add(randomDouble(boundLeft, boundRight));
                }

                double Farg = testFunction.ohodnot(arg);
                if (Farg < vhodnost)
                {
                    vhodnost = Farg;
                }
                arrayVhodnost.Add(vhodnost);
            }
            zapisDoCSV.Add(arrayVhodnost);
            zapis(zapisDoCSV, "result.csv");
        }
        public TimeSpan calcTime()
        {
            DateTime end = DateTime.UtcNow;
            TimeSpan difference = end.Subtract(start);
            return difference;
        }
        public void TabuSearch()
        {
            TSinstance = new TSinstance(TSPpatch);
            List<double> arrayFx = new List<double>();
            List<double> arrayFxBest = new List<double>();
            List<int> x0t = new List<int>();
            for (int i = 0; i < TSinstance.graph().Count; i++)
            {
                x0t.Add(i);
            }
            x0t = ShuffleList(x0t);
            double Fx0t = TSinstance.ohodnot(x0t);
            List<int> xBest = x0t;
            double Fmin = Fx0t;
            arrayFx.Add(Fmin);
            double doubleK = PercentPriestoru * 100;
            int k = (int)doubleK;
            List<upsyl> zoznamZmien = new List<upsyl>();
            zoznamZmien = generujRandomZmeny(x0t, pocetSusedov);

            Queue<upsyl> TL = new Queue<upsyl>();

            int t = 1;
            double tMax = pocetOhodnoteni / pocetSusedov;

            upsyl upsylonLoc = new upsyl(0, 0);
            while (t <= tMax)
            {
                List<int> xLoc = x0t;
                double Floc = Fx0t;
                zoznamZmien = generujRandomZmeny(x0t, pocetSusedov);
                for (int i = 0; i < zoznamZmien.Count; i++)
                {
                    upsyl upsylon = new upsyl(zoznamZmien.ElementAt(i).X, zoznamZmien.ElementAt(i).Y);
                    List<int> y = doplnZmenyDoVektora(x0t, upsylon.X, upsylon.Y);
                   
                    bool containUpsylon = false;
                    foreach (var item in TL)
                    {
                        if (item.X == upsylon.X && item.Y == upsylon.Y)
                        {
                            containUpsylon = true;
                            break;
                        }
                    }
                  
                    if (!containUpsylon)
                    {
                        double Fy = TSinstance.ohodnot(y);
                        arrayFx.Add(Fy);
                        if (Fy < Floc)
                        {
                            xLoc = y;
                            Floc = Fy;
                            upsylonLoc = upsylon;                         
                        }
                    }
                }
                if (Floc < Fmin)
                {
                    Fmin = Floc;
                    xBest = xLoc;                   
                }
                arrayFxBest.Add(Fmin);
                if (TL.Count < k)
                {
                    TL.Enqueue(upsylonLoc);
                }
                else
                {
                    TL.Dequeue();
                    TL.Enqueue(upsylonLoc);
                }         
                t++;
                x0t = xLoc;
            }
            zapisDoCSVbest.Add(arrayFxBest);
            zapis(zapisDoCSVbest, "best.csv");
            zapisDoCSV.Add(arrayFx);
            zapis(zapisDoCSV, "result.csv");
        }

        private List<upsyl> generujRandomZmeny(List<int> x0t, int maxSusedov)
        {
            List<int> disableSwap = new List<int>();
            List<upsyl> neighborhood = new List<upsyl>();

            for (int i = 0; i < maxSusedov; i++)
            {
                int first = randomInt(0, x0t.Count - 1);
                while (disableSwap.Contains(first))
                {
                    first = randomInt(0, x0t.Count - 1);
                }
                int second = randomInt(0, x0t.Count - 1);
                while (first == second || disableSwap.Contains(second))
                {
                    second = randomInt(0, x0t.Count - 1);
                }
                upsyl neighbour = new upsyl(first, second);
                neighborhood.Add(neighbour);
                disableSwap.Add(first);
                disableSwap.Add(second);
            }
            return neighborhood;

        }
        public List<int> doplnZmenyDoVektora(List<int> list, int first, int second)
        {
            int indexFirst = list.IndexOf(first);
            int indexSecond = list.IndexOf(second);
            List<int> tmp = new List<int>(list);
            tmp.RemoveAt(indexFirst);
            tmp.Insert(indexFirst, second);
            tmp.RemoveAt(indexSecond);
            tmp.Insert(indexSecond, first);
            return tmp;
        }

        private List<E> ShuffleList<E>(List<E> inputList)
        {
            List<E> randomList = new List<E>();

            Random r = new Random();
            int randomIndex = 0;
            while (inputList.Count > 0)
            {
                randomIndex = r.Next(0, inputList.Count); //Choose a random object in the list
                randomList.Add(inputList[randomIndex]); //add it to the new, random list
                inputList.RemoveAt(randomIndex); //remove to avoid duplicates
            }

            return randomList; //return the new random list
        }
        public void LocalSearch()
        {
            List<double> arrayFx = new List<double>();
            List<double> x = new List<double>();
            x.Add(randomDouble(boundLeft, boundRight));
            x.Add(randomDouble(boundLeft, boundRight));
            List<double> xLoc;
            xLoc = x;

            double Fx = testFunction.ohodnot(x);
            arrayFx.Add(Fx);
            double FxLoc = Fx;

            bool tau = true;
            List<List<double>> mnozinaSusedov;

            while (tau)
            {
                tau = false;
                mnozinaSusedov = generujDeteSusedov(PercentPriestoru, xLoc);
                foreach (var item in mnozinaSusedov)
                {
                    double var = testFunction.ohodnot(item);
                    if (var < FxLoc)
                    {
                        FxLoc = var;
                        xLoc = item;
                    }
                }
                if (FxLoc < Fx)
                {
                    Fx = FxLoc;
                    tau = true;
                }
                arrayFx.Add(Fx);
            }
            zapisDoCSV.Add(arrayFx);
            zapis(zapisDoCSV, "result.csv");
        }
        public List<List<double>> generujDeteSusedov(double rozsahSusedstva, List<Double> x)
        {
            List<List<double>> susedia = new List<List<double>>();
            double rozsah = Math.Abs(boundLeft) + boundRight;
            rozsah *= rozsahSusedstva;
            rozsah *= 0.5;
            double min = 0;
            double max = 0;
            List<List<double>> hranicePreKazdeX = new List<List<double>>();
            double zostatokZlava = 0;
            double zostatokSprava = 0;

            foreach (var localX in x)
            {
                zostatokSprava = 0;
                zostatokZlava = 0;
                List<double> hranicePreJednoX = new List<double>();
                if (localX - rozsah < boundLeft)
                {
                    zostatokZlava = Math.Abs(localX) - Math.Abs(boundLeft);
                    zostatokZlava = Math.Abs(zostatokZlava);
                    zostatokZlava -= rozsah;
                    zostatokZlava = Math.Abs(zostatokZlava);
                    min = boundLeft;
                }
                else
                {
                    min = localX - rozsah;
                }
                if (localX + rozsah > boundRight)
                {
                    zostatokSprava = Math.Abs(localX) - Math.Abs(boundRight);
                    zostatokSprava = Math.Abs(zostatokSprava);
                    zostatokSprava -= rozsah;
                    zostatokSprava = Math.Abs(zostatokSprava);
                    max = boundRight;
                }
                else
                {
                    max = localX + rozsah;
                }
                if (zostatokZlava > 0)
                {
                    max += zostatokZlava;
                }
                if (zostatokSprava > 0)
                {
                    min -= zostatokSprava;
                }
                hranicePreJednoX.Add(min);
                hranicePreJednoX.Add(max);
                hranicePreKazdeX.Add(hranicePreJednoX);
            }
            int polovicaSusedov = pocetSusedov / 2;
            List<double> vstup;

            for (int i = 0; i < pocetSusedov; i++)
            {
                vstup = new List<double>();
                for (int j = 0; j < x.Count; j++)
                {
                    if (i <= polovicaSusedov)
                    {
                        if ((j + 1) % 2 != 0)
                        {
                            vstup.Add(x.ElementAt(0));
                        }
                        else
                        {
                            double aktualBod = ((double)polovicaSusedov - (double)i) / (double)polovicaSusedov;
                            aktualBod = (rozsah * 2) * aktualBod;
                            vstup.Add(hranicePreKazdeX.ElementAt(j).ElementAt(0) + aktualBod);
                        }
                    }
                    else
                    {
                        if ((j + 1) % 2 != 0)
                        {
                            double aktualBod = ((double)i - (double)polovicaSusedov) / (double)polovicaSusedov;
                            aktualBod = (rozsah * 2) * aktualBod;
                            vstup.Add(hranicePreKazdeX.ElementAt(j).ElementAt(0) + aktualBod);

                        }
                        else
                        {
                            vstup.Add(x.ElementAt(1));
                        }
                    }
                }
                susedia.Add(vstup);
            }

            return susedia;
        }
        public List<List<double>> generujStochaSusedov(double rozsahSusedstva, List<Double> x, int pocetSusedov)
        {
            List<List<double>> susedia = new List<List<double>>();
            double rozsah = Math.Abs(boundLeft) + boundRight;
            rozsah *= rozsahSusedstva;
            rozsah *= 0.5;
            double min = 0;
            double max = 0;
            List<List<double>> hranicePreKazdeX = new List<List<double>>();
            //   double zostatok = 0;
            double zostatokZlava = 0;
            double zostatokSprava = 0;
            foreach (var localX in x)
            {
                zostatokSprava = 0;
                zostatokZlava = 0;
                List<double> hranicePreJednoX = new List<double>();
                if (localX - rozsah < boundLeft)
                {
                    zostatokZlava = Math.Abs(localX) - Math.Abs(boundLeft);
                    zostatokZlava = Math.Abs(zostatokZlava);
                    zostatokZlava -= rozsah;
                    zostatokZlava = Math.Abs(zostatokZlava);
                    min = boundLeft;
                }
                else
                {
                    min = localX - rozsah;
                }
                if (localX + rozsah > boundRight)
                {
                    zostatokSprava = Math.Abs(localX) - Math.Abs(boundRight);
                    zostatokSprava = Math.Abs(zostatokSprava);
                    zostatokSprava -= rozsah;
                    zostatokSprava = Math.Abs(zostatokSprava);
                    max = boundRight;
                }
                else
                {
                    max = localX + rozsah;
                }
                if (zostatokZlava > 0)
                {
                    max += zostatokZlava;
                }
                if (zostatokSprava > 0)
                {
                    min -= zostatokSprava;
                }
                hranicePreJednoX.Add(min);
                hranicePreJednoX.Add(max);
                hranicePreKazdeX.Add(hranicePreJednoX);
            }
            List<double> vstup;
            for (int i = 0; i < pocetSusedov; i++)
            {
                vstup = new List<double>();
                foreach (var item in hranicePreKazdeX)
                {
                    vstup.Add(randomDouble(item.ElementAt(0), item.ElementAt(1)));
                }
                susedia.Add(vstup);
            }
            return susedia;

        }
        public void SA()
        {
            List<double> arrayFx0 = new List<double>();
            List<double> arrayFxBest = new List<double>();
            List<double> x0 = new List<double>();
            x0.Add(randomDouble(boundLeft, boundRight));
            x0.Add(randomDouble(boundLeft, boundRight));
            List<double> xBest = x0;
            List<double> x = new List<double>();
            List<List<double>> susedia = new List<List<double>>();
            double Fx0 = testFunction.ohodnot(x0);
            double FxBest = Fx0;
            arrayFx0.Add(Fx0);
            arrayFxBest.Add(Fx0);
            double T = T0;
            double alfa = 0.95;
            int nt = pocetSusedov;
            double deltaF;
            List<string> debug = new List<string>();

            while (T > Tf)
            {
                for (int i = 0; i < nt; i++)
                {
                    susedia = generujStochaSusedov(PercentPriestoru, x0, 1);
                    x = susedia.ElementAt(0);
                    double fx = testFunction.ohodnot(x);
                    deltaF = fx - Fx0;
                    if (deltaF < 0)
                    {
                        x0 = x;
                        Fx0 = fx;
                        if (fx < FxBest)
                        {
                            xBest = x;
                            FxBest = fx;
                        }
                    }
                    else
                    {
                        double r = randomDouble(0, 1);
                        double rovnica = Math.Pow(Math.E, ((-1 * deltaF) / T));
                        if (r < rovnica)
                        {
                            x0 = x;
                            Fx0 = fx;
                        }
                    }
                    arrayFx0.Add(Fx0);
                    arrayFxBest.Add(FxBest);
                }
                T = alfa * T;
            }
            zapisDoCSV.Add(arrayFx0);
            zapisDoCSVbest.Add(arrayFxBest);
            zapis(zapisDoCSV, "result.csv");
            zapis(zapisDoCSVbest, "best.csv");
        }
        public void StochastickHC()
        {
            List<double> arrayFx = new List<double>();
            List<double> x = new List<double>();
            x.Add(randomDouble(boundLeft, boundRight));
            x.Add(randomDouble(boundLeft, boundRight));
            List<double> xLoc;
            xLoc = x;
            int t = 1;
            int tMax = (int)pocetOhodnoteni;
            double Fx = testFunction.ohodnot(x);
            arrayFx.Add(Fx);
            double FxLoc = Fx;
            List<List<double>> mnozinaSusedov;
            bool first = true;

            while (t < pocetOhodnoteni)
            {
                mnozinaSusedov = generujStochaSusedov(PercentPriestoru, xLoc, pocetSusedov);
                first = true;
                foreach (var item in mnozinaSusedov)
                {
                    double fx = testFunction.ohodnot(item);
                    if (first)
                    {
                        FxLoc = fx;
                        first = false;
                    }
                    if (fx <= FxLoc)
                    {
                        FxLoc = fx;
                        xLoc = item;
                    }
                }
                if (FxLoc < Fx)
                {
                    Fx = FxLoc;
                }
                t++;
                arrayFx.Add(Fx);
            }
            zapisDoCSV.Add(arrayFx);
            zapis(zapisDoCSV, "result.csv");
        }
        public double getVhodnost()
        {
            double vhodnost = 1;
            for (int i = 0; i < pocetDimenzii; i++)
            {
                vhodnost += boundRight * boundRight;
            }
            return vhodnost;
        }
        public void zapis(List<List<Double>> navrat, string fileName)
        {
            if (overall == 29)
            {
                string csvpatch = patch;
                csvpatch = csvpatch + fileName;
                StringBuilder csvcontent = new StringBuilder();
                File.WriteAllText(csvpatch, string.Empty);
                //    csvcontent.AppendLine("ECF;result");

                int longest = 0;
                for (int i = 0; i < navrat.Count; i++)
                {
                    if (navrat.ElementAt(i).Count > longest)
                    {
                        longest = navrat.ElementAt(i).Count;
                    }
                }
                string firstLine = " ;";
                for (int j = 0; j < navrat.Count; j++)
                {
                    firstLine = firstLine + j.ToString() + ";";
                }
                csvcontent.AppendLine(firstLine);
                for (int i = 0; i < longest; i++)
                {
                    string line = i.ToString() + ";";

                    foreach (var item in navrat)
                    {
                        try
                        {
                            line = line + item.ElementAt(i).ToString() + ";";
                        }
                        catch (Exception)
                        {
                            line = line + " ;";
                        }
                    }

                    csvcontent.AppendLine(line);
                }

                File.AppendAllText(csvpatch, csvcontent.ToString());
            }

        }
        public double randomDouble(double min, double max)
        {
            return random.NextDouble() * (max - min) + min;
        }
        public int randomInt(int min, int max)
        {
            return random.Next(min, max);
        }
    }

    class TSinstance
    {
        SortedList<int, Dictionary<int, double>> TSobject = new SortedList<int, Dictionary<int, double>>();
        public TSinstance(string _TSpatch)
        {
            loader(_TSpatch);
        }
        public double ohodnot(List<int> vstup)
        {
            double hodnota = 0;
            for (int i = 0; i < vstup.Count; i++)
            {
                if (i < vstup.Count - 1)
                {
                    int nexCity = vstup.ElementAt(i + 1);
                    int currentCity = vstup.ElementAt(i);
                    hodnota += TSobject.ElementAt(currentCity).Value[nexCity];
                }
            }
            return hodnota;
        }
        public SortedList<int, Dictionary<int, double>> graph()
        {
            return TSobject;
        }
        public void loader(string TSpatch)
        {
            XmlSerializer ser = new XmlSerializer(typeof(Graph));
            StreamReader reader = new StreamReader(TSpatch);
            Graph graph = (Graph)ser.Deserialize(reader);

            for (int i = 0; i < graph.vertex.Count; i++)
            {
                Dictionary<int, double> values = new Dictionary<int, double>();
                for (int j = 0; j < graph.vertex.ElementAt(i).Edge.Length; j++)
                {
                    string cost = graph.vertex.ElementAt(i).Edge.ElementAt(j).cost;
                    int index = cost.IndexOf('e');
                    cost = cost.Substring(0, index);
                    double costDouble = double.Parse(cost, System.Globalization.CultureInfo.InvariantCulture);

                    string nasobok = graph.vertex.ElementAt(i).Edge.ElementAt(j).cost;
                    nasobok = nasobok.Substring(nasobok.IndexOf('e') + 1);
                    double ciselnyNasobok = double.Parse(nasobok, System.Globalization.CultureInfo.InvariantCulture);
                    ciselnyNasobok = Math.Pow(10, ciselnyNasobok);
                    costDouble *= ciselnyNasobok;
                    int edge = Convert.ToInt16(graph.vertex.ElementAt(i).Edge.ElementAt(j).edge);
                    values.Add(edge, costDouble);
                }
                TSobject.Add(i, values);
            }
        }

    }

}


[Serializable]
[XmlRoot("travellingSalesmanProblemInstance")]
public class Graph
{
    [XmlArray("graph"), XmlArrayItem("vertex")]
    public List<Vertex> vertex { get; set; }
}

public class Vertex
{

    [XmlElement(ElementName = "edge")]
    public Edge[] Edge { get; set; }
}
public class Edge
{
    [XmlText]
    public string edge { get; set; }

    [XmlAttribute(AttributeName = "cost")]
    public string cost { get; set; }
}



public class LimitedQueue<T> : Queue<T>
{
    public int Limit { get; set; }

    public LimitedQueue(int limit) : base(limit)
    {
        Limit = limit;
    }

    public new void Enqueue(T item)
    {
        while (Count >= Limit)
        {
            Dequeue();
        }
        base.Enqueue(item);
    }
}
struct upsyl
{
    private int x;
    public int X { get => x; set => x = value; }
    public int Y
    {
        get
        { return y; }
        private set
        {
            if (value > x)
            {
                y = value;
            }
            else
            {
                y = x;
                x = value;
            }
        }
    }
    private int y;
    public upsyl(int _X, int _Y)
    {
        // x < y
        x = _X;
        y = 0;
        Y = _Y;

    }

}