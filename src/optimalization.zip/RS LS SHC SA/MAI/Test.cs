﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAI
{
    class Test
    {
        string typ;
        public Test(string Typ)
        {
            typ = Typ;
        }
        public double ohodnot(List<double> vstup)
        {
            double navrat = 0;
            switch (typ)
            {
                case "radioDeJong1":
                    navrat = DeJong1(vstup);
                    break;
                case "radioDeJong2":
                    navrat = DeJong2(vstup);
                    break;
                case "radioSchwefel":
                    navrat = Schwefel(vstup);
                    break;
                default:
                    break;
            }           
            return navrat;
        }
        public double Schwefel(List<double> vstup)
        {
            double navrat = 0;
            for (int i = 0; i < vstup.Count; i++)
            {
                double local = 0;
                local = Math.Abs(vstup.ElementAt(i));
                local = Math.Sqrt(local);
                local = Math.Sin(local);
                local *= (vstup.ElementAt(i) * -1);
                navrat += local;
            }
            return navrat;
        }
        public double DeJong2(List<double> vstup)
        {
            double navrat = 0;
            for (int i = 0; i < vstup.Count-1; i++)
            {
                double firstBracket = 0;
                firstBracket = (vstup.ElementAt(i) * vstup.ElementAt(i));
                firstBracket -= vstup.ElementAt(i + 1);
                firstBracket *= firstBracket;
                firstBracket *= 100;
                double secondBracket = 0;
                secondBracket = 1 - vstup.ElementAt(i);
                secondBracket *= secondBracket;
                navrat += firstBracket + secondBracket;
            }
            return navrat;
        }
        public double DeJong1(List<double> vstup)
        {
            double navrat = 0;
            foreach (var item in vstup)
            {
                navrat += item * item;
            }
            return navrat;
        }
    }
}
