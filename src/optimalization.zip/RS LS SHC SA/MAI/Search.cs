﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MAI
{
    class Search
    {
        List<List<double>> zapisDoCSV = new List<List<double>>();
        List<List<double>> zapisDoCSVbest = new List<List<double>>();
        double boundLeft;
        double boundRight;
        double pocetOhodnoteni;
        int pocetDimenzii = 2;
        string search;
        string test;
        int pocetSusedov;
        double rozsahSusedstva;
        Random random = new Random();
        Test testFunction;
        double T0;
        double Tf;
        int overall = 0;
        string patch;
        public Search(int Bound, int PocetOhodnoteni, int PocetSusedov,
            double PercentPriestoru, string Search, string Test, int _Tf, int _T0, string Patch)
        {
            boundLeft = Bound * -1;
            boundRight = Bound;
            pocetOhodnoteni = PocetOhodnoteni;
            search = Search;
            test = Test;
            pocetSusedov = PocetSusedov;
            rozsahSusedstva = PercentPriestoru;
            Tf = _Tf;
            T0 = _T0;
            patch = Patch;

        }
        public void rataj()
        {
            testFunction = new Test(test);
            for (int i = 0; i < 30; i++)
            {
                switch (search)
                {
                    case "radioRandom":
                        RandomSearch();
                        break;
                    case "radioLocal":
                        LocalSearch();
                        break;
                    case "radioHill":
                        StochasticHillClimber();
                        break;
                    case "radioZihanie":
                        SimulovaneZihanie();
                        break;
                    default:
                        break;
                }
                overall++;
            }

        }

        public void RandomSearch()
        {

            List<double> arrayVhodnost = new List<double>();
            List<double> arg;
            double vhodnost = getVhodnost();

            for (int i = 0; i < pocetOhodnoteni; i++)
            {
                arg = new List<double>();
                for (int j = 0; j < pocetDimenzii; j++)
                {
                    arg.Add(randomDouble(boundLeft, boundRight));
                }

                double Farg = testFunction.ohodnot(arg);
                if (Farg < vhodnost)
                {
                    vhodnost = Farg;
                }
                arrayVhodnost.Add(vhodnost);
            }
            zapisDoCSV.Add(arrayVhodnost);
            zapis(zapisDoCSV, "result.csv");
        }

        public void LocalSearch()
        {
            List<double> arrayFx = new List<double>();
            List<double> x = new List<double>();
            x.Add(randomDouble(boundLeft, boundRight));
            x.Add(randomDouble(boundLeft, boundRight));
            List<double> xLoc;
            xLoc = x;

            double Fx = testFunction.ohodnot(x);
            arrayFx.Add(Fx);
            double FxLoc = Fx;

            bool tau = true;
            List<List<double>> mnozinaSusedov;

            while (tau)
            {
                tau = false;
                mnozinaSusedov = generujDeteSusedov(rozsahSusedstva, xLoc);
                foreach (var item in mnozinaSusedov)
                {
                    double var = testFunction.ohodnot(item);
                    if (var < FxLoc)
                    {
                        FxLoc = var;
                        xLoc = item;
                    }
                }
                if (FxLoc < Fx)
                {
                    Fx = FxLoc;
                    tau = true;
                }
                arrayFx.Add(Fx);
            }
            zapisDoCSV.Add(arrayFx);
            zapis(zapisDoCSV, "result.csv");
        }
        public List<List<double>> generujDeteSusedov(double rozsahSusedstva, List<Double> x)
        {
            List<List<double>> susedia = new List<List<double>>();
            double rozsah = Math.Abs(boundLeft) + boundRight;
            rozsah *= rozsahSusedstva;
            rozsah *= 0.5;
            double min = 0;
            double max = 0;
            List<List<double>> hranicePreKazdeX = new List<List<double>>();
            double zostatokZlava = 0;
            double zostatokSprava = 0;

            foreach (var localX in x)
            {
                zostatokSprava = 0;
                zostatokZlava = 0;
                List<double> hranicePreJednoX = new List<double>();
                if (localX - rozsah < boundLeft)
                {
                    zostatokZlava = Math.Abs(localX) - Math.Abs(boundLeft);
                    zostatokZlava = Math.Abs(zostatokZlava);
                    zostatokZlava -= rozsah;
                    zostatokZlava = Math.Abs(zostatokZlava);
                    min = boundLeft;
                }
                else
                {
                    min = localX - rozsah;
                }
                if (localX + rozsah > boundRight)
                {
                    zostatokSprava = Math.Abs(localX) - Math.Abs(boundRight);
                    zostatokSprava = Math.Abs(zostatokSprava);
                    zostatokSprava -= rozsah;
                    zostatokSprava = Math.Abs(zostatokSprava);
                    max = boundRight;
                }
                else
                {
                    max = localX + rozsah;
                }
                if (zostatokZlava > 0)
                {
                    max += zostatokZlava;
                }
                if (zostatokSprava > 0)
                {
                    min -= zostatokSprava;
                }
                hranicePreJednoX.Add(min);
                hranicePreJednoX.Add(max);
                hranicePreKazdeX.Add(hranicePreJednoX);
            }
            int polovicaSusedov = pocetSusedov / 2;
            List<double> vstup;

            for (int i = 0; i < pocetSusedov; i++)
            {
                vstup = new List<double>();
                for (int j = 0; j < x.Count; j++)
                {
                    if (i <= polovicaSusedov)
                    {
                        if ((j + 1) % 2 != 0)
                        {
                            vstup.Add(x.ElementAt(0));
                        }
                        else
                        {
                            double aktualBod = ((double)polovicaSusedov - (double)i) / (double)polovicaSusedov;
                            aktualBod = (rozsah * 2) * aktualBod;
                            vstup.Add(hranicePreKazdeX.ElementAt(j).ElementAt(0) + aktualBod);
                        }
                    }
                    else
                    {
                        if ((j + 1) % 2 != 0)
                        {
                            double aktualBod = ((double)i - (double)polovicaSusedov) / (double)polovicaSusedov;
                            aktualBod = (rozsah * 2) * aktualBod;
                            vstup.Add(hranicePreKazdeX.ElementAt(j).ElementAt(0) + aktualBod);

                        }
                        else
                        {
                            vstup.Add(x.ElementAt(1));
                        }
                    }
                }
                susedia.Add(vstup);
            }

            return susedia;
        }
        public List<List<double>> generujStochaSusedov(double rozsahSusedstva, List<Double> x, int pocetSusedov)
        {
            List<List<double>> susedia = new List<List<double>>();
            double rozsah = Math.Abs(boundLeft) + boundRight;
            rozsah *= rozsahSusedstva;
            rozsah *= 0.5;
            double min = 0;
            double max = 0;
            List<List<double>> hranicePreKazdeX = new List<List<double>>();
            double zostatok = 0;
            double zostatokZlava = 0;
            double zostatokSprava = 0;
            foreach (var localX in x)
            {
                zostatokSprava = 0;
                zostatokZlava = 0;
                List<double> hranicePreJednoX = new List<double>();
                if (localX - rozsah < boundLeft)
                {
                    zostatokZlava = Math.Abs(localX) - Math.Abs(boundLeft);
                    zostatokZlava = Math.Abs(zostatokZlava);
                    zostatokZlava -= rozsah;
                    zostatokZlava = Math.Abs(zostatokZlava);
                    min = boundLeft;
                }
                else
                {
                    min = localX - rozsah;
                }
                if (localX + rozsah > boundRight)
                {
                    zostatokSprava = Math.Abs(localX) - Math.Abs(boundRight);
                    zostatokSprava = Math.Abs(zostatokSprava);
                    zostatokSprava -= rozsah;
                    zostatokSprava = Math.Abs(zostatokSprava);
                    max = boundRight;
                }
                else
                {
                    max = localX + rozsah;
                }
                if (zostatokZlava > 0)
                {
                    max += zostatokZlava;
                }
                if (zostatokSprava > 0)
                {
                    min -= zostatokSprava;
                }
                hranicePreJednoX.Add(min);
                hranicePreJednoX.Add(max);
                hranicePreKazdeX.Add(hranicePreJednoX);
            }
            List<double> vstup;
            for (int i = 0; i < pocetSusedov; i++)
            {
                vstup = new List<double>();
                foreach (var item in hranicePreKazdeX)
                {
                    vstup.Add(randomDouble(item.ElementAt(0), item.ElementAt(1)));
                }
                susedia.Add(vstup);
            }
            return susedia;

        }
        public void SimulovaneZihanie()
        {
            List<double> arrayFx0 = new List<double>();
            List<double> arrayFxBest = new List<double>();
            List<double> x0 = new List<double>();
            x0.Add(randomDouble(boundLeft, boundRight));
            x0.Add(randomDouble(boundLeft, boundRight));
            List<double> xBest = x0;
            List<double> x = new List<double>();
            List<List<double>> susedia = new List<List<double>>();
            double Fx0 = testFunction.ohodnot(x0);
            double FxBest = Fx0;
            arrayFx0.Add(Fx0);
            arrayFxBest.Add(Fx0);
            double T = T0;
            double alfa = 0.95;
            int nt = pocetSusedov;
            double deltaF;
            List<string> debug = new List<string>();

            while (T > Tf)
            {
                for (int i = 0; i < nt; i++)
                {
                    susedia = generujStochaSusedov(rozsahSusedstva, x0, 1);
                    x = susedia.ElementAt(0);
                    double fx = testFunction.ohodnot(x);
                    deltaF = fx - Fx0;
                    if (deltaF < 0)
                    {
                        x0 = x;
                        Fx0 = fx;
                        if (fx < FxBest)
                        {
                            xBest = x;
                            FxBest = fx;
                        }
                    }
                    else
                    {
                        double r = randomDouble(0, 1);
                        double rovnica = Math.Pow(Math.E, ((-1 * deltaF) / T));
                        if (r < rovnica)
                        {
                            x0 = x;
                            Fx0 = fx;
                        }
                    }
                    arrayFx0.Add(Fx0);
                    arrayFxBest.Add(FxBest);
                }
                T = alfa * T;
            }
            zapisDoCSV.Add(arrayFx0);
            zapisDoCSVbest.Add(arrayFxBest);
            zapis(zapisDoCSV, "result.csv");
            zapis(zapisDoCSVbest, "best.csv");
        }
        public void StochasticHillClimber()
        {
            List<double> arrayFx = new List<double>();
            List<double> x = new List<double>();
            x.Add(randomDouble(boundLeft, boundRight));
            x.Add(randomDouble(boundLeft, boundRight));
            List<double> xLoc;
            xLoc = x;
            int t = 1;
            int tMax = (int)pocetOhodnoteni;
            double Fx = testFunction.ohodnot(x);
            arrayFx.Add(Fx);
            double FxLoc = Fx;
            List<List<double>> mnozinaSusedov;
            bool first = true;

            while (t < pocetOhodnoteni)
            {
                mnozinaSusedov = generujStochaSusedov(rozsahSusedstva, xLoc, pocetSusedov);
                first = true;
                foreach (var item in mnozinaSusedov)
                {
                    double fx = testFunction.ohodnot(item);
                    if (first)
                    {
                        FxLoc = fx;
                        first = false;
                    }
                    if (fx <= FxLoc)
                    {
                        FxLoc = fx;
                        xLoc = item;
                    }
                }
                if (FxLoc < Fx)
                {
                    Fx = FxLoc;
                }
                t++;
                arrayFx.Add(Fx);
            }
            zapisDoCSV.Add(arrayFx);
            zapis(zapisDoCSV, "result.csv");
        }


        public double getVhodnost()
        {
            double vhodnost = 1;
            for (int i = 0; i < pocetDimenzii; i++)
            {
                vhodnost += boundRight * boundRight;
            }
            return vhodnost;
        }
        public void zapis(List<List<Double>> navrat, string fileName)
        {
            if (overall == 29)
            {
                string csvpatch = patch;
                csvpatch = csvpatch + fileName;
                StringBuilder csvcontent = new StringBuilder();
                File.WriteAllText(csvpatch, string.Empty);
                //    csvcontent.AppendLine("ECF;result");

                int longest = 0;
                for (int i = 0; i < navrat.Count; i++)
                {
                    if (navrat.ElementAt(i).Count > longest)
                    {
                        longest = navrat.ElementAt(i).Count;
                    }
                }
                string firstLine = " ;";
                for (int j = 0; j < navrat.Count; j++)
                {
                    firstLine = firstLine + j.ToString() + ".beh;";
                }
                csvcontent.AppendLine(firstLine);
                for (int i = 0; i < longest; i++)
                {
                    string line = i.ToString() + ".FES;";

                    foreach (var item in navrat)
                    {
                        try
                        {
                            line = line + item.ElementAt(i).ToString() + ";";
                        }
                        catch (Exception)
                        {
                            line = line + " ;";
                        }
                    }

                    csvcontent.AppendLine(line);
                }

                File.AppendAllText(csvpatch, csvcontent.ToString());
            }

        }
        public double randomDouble(double min, double max)
        {
            return random.NextDouble() * (max - min) + min;
        }
    }
}
