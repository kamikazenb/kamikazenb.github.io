﻿namespace MAI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioZihanie = new System.Windows.Forms.RadioButton();
            this.radioRandom = new System.Windows.Forms.RadioButton();
            this.radioLocal = new System.Windows.Forms.RadioButton();
            this.radioHill = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioSchwefel = new System.Windows.Forms.RadioButton();
            this.radioDeJong2 = new System.Windows.Forms.RadioButton();
            this.radioDeJong1 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.numericHranicaZlava = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.numericPocetSusedov = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.numericPercentPriestoru = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericMaxT = new System.Windows.Forms.NumericUpDown();
            this.numericMinT = new System.Windows.Forms.NumericUpDown();
            this.textPatch = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonVypocet = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericHranicaZlava)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericPocetSusedov)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericPercentPriestoru)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericMaxT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericMinT)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(222, 361);
            this.panel1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.numericHranicaZlava, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.numericPocetSusedov, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.numericPercentPriestoru, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.numericUpDown1, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.numericMaxT, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.numericMinT, 1, 15);
            this.tableLayoutPanel1.Controls.Add(this.textPatch, 1, 16);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 16);
            this.tableLayoutPanel1.Controls.Add(this.buttonVypocet, 1, 17);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 14);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 15);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 6);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 18;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(216, 352);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.TableLayoutPanel1_Paint_1);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioZihanie);
            this.groupBox1.Controls.Add(this.radioRandom);
            this.groupBox1.Controls.Add(this.radioLocal);
            this.groupBox1.Controls.Add(this.radioHill);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(102, 121);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search";
            // 
            // radioZihanie
            // 
            this.radioZihanie.AutoSize = true;
            this.radioZihanie.Location = new System.Drawing.Point(6, 88);
            this.radioZihanie.Name = "radioZihanie";
            this.radioZihanie.Size = new System.Drawing.Size(81, 17);
            this.radioZihanie.TabIndex = 3;
            this.radioZihanie.TabStop = true;
            this.radioZihanie.Text = "Sim. zihanie";
            this.radioZihanie.UseVisualStyleBackColor = true;
            // 
            // radioRandom
            // 
            this.radioRandom.AutoSize = true;
            this.radioRandom.Checked = true;
            this.radioRandom.Location = new System.Drawing.Point(6, 19);
            this.radioRandom.Name = "radioRandom";
            this.radioRandom.Size = new System.Drawing.Size(65, 17);
            this.radioRandom.TabIndex = 3;
            this.radioRandom.TabStop = true;
            this.radioRandom.Text = "Random";
            this.radioRandom.UseVisualStyleBackColor = true;
            // 
            // radioLocal
            // 
            this.radioLocal.AutoSize = true;
            this.radioLocal.Location = new System.Drawing.Point(6, 42);
            this.radioLocal.Name = "radioLocal";
            this.radioLocal.Size = new System.Drawing.Size(51, 17);
            this.radioLocal.TabIndex = 4;
            this.radioLocal.Text = "Local";
            this.radioLocal.UseVisualStyleBackColor = true;
            // 
            // radioHill
            // 
            this.radioHill.AutoSize = true;
            this.radioHill.Location = new System.Drawing.Point(6, 65);
            this.radioHill.Name = "radioHill";
            this.radioHill.Size = new System.Drawing.Size(76, 17);
            this.radioHill.TabIndex = 5;
            this.radioHill.Text = "Hill Climber";
            this.radioHill.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioSchwefel);
            this.groupBox2.Controls.Add(this.radioDeJong2);
            this.groupBox2.Controls.Add(this.radioDeJong1);
            this.groupBox2.Location = new System.Drawing.Point(111, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(102, 121);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Test";
            // 
            // radioSchwefel
            // 
            this.radioSchwefel.AutoSize = true;
            this.radioSchwefel.Location = new System.Drawing.Point(4, 65);
            this.radioSchwefel.Name = "radioSchwefel";
            this.radioSchwefel.Size = new System.Drawing.Size(69, 17);
            this.radioSchwefel.TabIndex = 2;
            this.radioSchwefel.Text = "Schwefel";
            this.radioSchwefel.UseVisualStyleBackColor = true;
            // 
            // radioDeJong2
            // 
            this.radioDeJong2.AutoSize = true;
            this.radioDeJong2.Location = new System.Drawing.Point(4, 42);
            this.radioDeJong2.Name = "radioDeJong2";
            this.radioDeJong2.Size = new System.Drawing.Size(72, 17);
            this.radioDeJong2.TabIndex = 1;
            this.radioDeJong2.Text = "de Jong 2";
            this.radioDeJong2.UseVisualStyleBackColor = true;
            // 
            // radioDeJong1
            // 
            this.radioDeJong1.AutoSize = true;
            this.radioDeJong1.Checked = true;
            this.radioDeJong1.Location = new System.Drawing.Point(4, 19);
            this.radioDeJong1.Name = "radioDeJong1";
            this.radioDeJong1.Size = new System.Drawing.Size(72, 17);
            this.radioDeJong1.TabIndex = 0;
            this.radioDeJong1.TabStop = true;
            this.radioDeJong1.Text = "de Jong 1";
            this.radioDeJong1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 26);
            this.label3.TabIndex = 9;
            this.label3.Text = "Hranica +/-";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numericHranicaZlava
            // 
            this.numericHranicaZlava.Location = new System.Drawing.Point(111, 130);
            this.numericHranicaZlava.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericHranicaZlava.Name = "numericHranicaZlava";
            this.numericHranicaZlava.Size = new System.Drawing.Size(102, 20);
            this.numericHranicaZlava.TabIndex = 0;
            this.numericHranicaZlava.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Cursor = System.Windows.Forms.Cursors.SizeNS;
            this.label4.Location = new System.Drawing.Point(3, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 26);
            this.label4.TabIndex = 10;
            this.label4.Text = "FES";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numericPocetSusedov
            // 
            this.numericPocetSusedov.Location = new System.Drawing.Point(111, 182);
            this.numericPocetSusedov.Name = "numericPocetSusedov";
            this.numericPocetSusedov.Size = new System.Drawing.Size(102, 20);
            this.numericPocetSusedov.TabIndex = 15;
            this.numericPocetSusedov.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 179);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 26);
            this.label1.TabIndex = 16;
            this.label1.Text = "Pocet susedov";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 205);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 26);
            this.label6.TabIndex = 18;
            this.label6.Text = "% rozsah susedstva";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numericPercentPriestoru
            // 
            this.numericPercentPriestoru.Location = new System.Drawing.Point(111, 208);
            this.numericPercentPriestoru.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericPercentPriestoru.Name = "numericPercentPriestoru";
            this.numericPercentPriestoru.Size = new System.Drawing.Size(102, 20);
            this.numericPercentPriestoru.TabIndex = 17;
            this.numericPercentPriestoru.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(111, 156);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(102, 20);
            this.numericUpDown1.TabIndex = 20;
            this.numericUpDown1.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // numericMaxT
            // 
            this.numericMaxT.Location = new System.Drawing.Point(111, 234);
            this.numericMaxT.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericMaxT.Name = "numericMaxT";
            this.numericMaxT.Size = new System.Drawing.Size(102, 20);
            this.numericMaxT.TabIndex = 14;
            this.numericMaxT.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // numericMinT
            // 
            this.numericMinT.Location = new System.Drawing.Point(111, 260);
            this.numericMinT.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericMinT.Name = "numericMinT";
            this.numericMinT.Size = new System.Drawing.Size(102, 20);
            this.numericMinT.TabIndex = 21;
            this.numericMinT.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // textPatch
            // 
            this.textPatch.Location = new System.Drawing.Point(111, 286);
            this.textPatch.Name = "textPatch";
            this.textPatch.Size = new System.Drawing.Size(100, 20);
            this.textPatch.TabIndex = 3;
            this.textPatch.Text = "d:\\\\";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 283);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 26);
            this.label2.TabIndex = 19;
            this.label2.Text = "Uloz do";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // buttonVypocet
            // 
            this.buttonVypocet.Location = new System.Drawing.Point(111, 312);
            this.buttonVypocet.Name = "buttonVypocet";
            this.buttonVypocet.Size = new System.Drawing.Size(75, 23);
            this.buttonVypocet.TabIndex = 8;
            this.buttonVypocet.Text = "Vypocet";
            this.buttonVypocet.UseVisualStyleBackColor = true;
            this.buttonVypocet.Click += new System.EventHandler(this.ButtonVypocet_ClickAsync);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 231);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 26);
            this.label5.TabIndex = 22;
            this.label5.Text = "Start. teplota";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label5.Click += new System.EventHandler(this.Label5_Click);
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 257);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 26);
            this.label7.TabIndex = 23;
            this.label7.Text = "Min. teplota";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 376);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(244, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(55, 17);
            this.toolStripStatusLabel1.Text = "welcome";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(244, 398);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(800, 500);
            this.MinimumSize = new System.Drawing.Size(260, 350);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericHranicaZlava)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericPocetSusedov)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericPercentPriestoru)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericMaxT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericMinT)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.NumericUpDown numericHranicaZlava;
        private System.Windows.Forms.RadioButton radioRandom;
        private System.Windows.Forms.RadioButton radioLocal;
        private System.Windows.Forms.RadioButton radioHill;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioSchwefel;
        private System.Windows.Forms.RadioButton radioDeJong2;
        private System.Windows.Forms.RadioButton radioDeJong1;
        private System.Windows.Forms.Button buttonVypocet;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numericMaxT;
        private System.Windows.Forms.NumericUpDown numericPocetSusedov;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numericPercentPriestoru;
        private System.Windows.Forms.RadioButton radioZihanie;
        private System.Windows.Forms.TextBox textPatch;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericMinT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
    }
}

