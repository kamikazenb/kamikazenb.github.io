﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MAI
{
    public partial class Form1 : Form
    {

        int bound;
        int boundRight;
        int pocetOhodnoteni;
        int noOfDimensions;
        int pocetSusedov;
        double percentPriestoru;
        int maxTeplota;
        int minTeplota;
        string patch;

        public Form1()
        {

            InitializeComponent();
            bound = (int)numericHranicaZlava.Value;
            pocetOhodnoteni = (int)numericMaxT.Value;
            noOfDimensions = 2;
            pocetSusedov = (int)numericPocetSusedov.Value;
            percentPriestoru = (double)numericPocetSusedov.Value/100;
            maxTeplota = (int)numericMaxT.Value;
            minTeplota = (int)numericMinT.Value;
            patch = textPatch.Text;
        }

        private void TableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SplitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SplitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }


        private async void ButtonVypocet_ClickAsync(object sender, EventArgs e)
        {
            var checkedRadio = new[] { groupBox1}
                    .SelectMany(g => g.Controls.OfType<RadioButton>()
                                             .Where(r => r.Checked));
            string search = "";
            string test = "";
            foreach (var c in checkedRadio)
            {
                search = c.Name;
            }
            checkedRadio = new[] { groupBox2 }
                  .SelectMany(g => g.Controls.OfType<RadioButton>()
                                           .Where(r => r.Checked));
            foreach (var c in checkedRadio)
            {
                test = c.Name;
            }
            toolStripStatusLabel1.Text = "calculating...";
            var progress = new Progress<string>(s => toolStripStatusLabel1.Text = s);
            await Task.Factory.StartNew(() => SecondThreadConcern.LongWork(progress, (int)numericHranicaZlava.Value,
                (int)numericMaxT.Value, (int)numericPocetSusedov.Value, (double)numericPocetSusedov.Value / 100, 
                search, 
              test, (int)numericMinT.Value, (int)numericMaxT.Value, textPatch.Text),
                                        TaskCreationOptions.LongRunning);
            toolStripStatusLabel1.Text = "completed";
        }

        private void NumericNoOfDimensions_ValueChanged(object sender, EventArgs e)
        {

        }

        private void TableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }
    }
    class SecondThreadConcern
    {
        public static void LongWork(IProgress<string> progress, int bound,
            int pocetOhodnoteni,  int pocetSusedov, double percentPriestoru,
            string search, string test, int Tf, int T0, string patch)
        {
            // Perform a long running work...

            Search rs = new Search(bound, pocetOhodnoteni, pocetSusedov,
               percentPriestoru, search, test, Tf, T0, patch);
            rs.rataj();
            progress.Report("calculating...");

        }
    }
}
