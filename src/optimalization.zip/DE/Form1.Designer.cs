﻿namespace MAI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.diffEvo = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioSchwefel = new System.Windows.Forms.RadioButton();
            this.radioDeJong2 = new System.Windows.Forms.RadioButton();
            this.radioDeJong1 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.intNoOfD = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.intNP = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.doubleF = new System.Windows.Forms.NumericUpDown();
            this.intGmax = new System.Windows.Forms.NumericUpDown();
            this.doubleCR = new System.Windows.Forms.NumericUpDown();
            this.textPatch = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonVypocet = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.intNoOfD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.intNP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.intGmax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleCR)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(253, 299);
            this.panel1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.68016F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.31984F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.intNoOfD, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.intNP, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.doubleF, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.intGmax, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.doubleCR, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.textPatch, 1, 16);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 16);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 14);
            this.tableLayoutPanel1.Controls.Add(this.buttonVypocet, 1, 18);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 6);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 19;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(247, 280);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.TableLayoutPanel1_Paint_1);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.diffEvo);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(133, 86);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search";
            // 
            // diffEvo
            // 
            this.diffEvo.AutoSize = true;
            this.diffEvo.Checked = true;
            this.diffEvo.Location = new System.Drawing.Point(6, 19);
            this.diffEvo.Name = "diffEvo";
            this.diffEvo.Size = new System.Drawing.Size(96, 17);
            this.diffEvo.TabIndex = 3;
            this.diffEvo.TabStop = true;
            this.diffEvo.Text = "DE/rand/1/bin";
            this.diffEvo.UseVisualStyleBackColor = true;
            this.diffEvo.CheckedChanged += new System.EventHandler(this.radioRandom_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioSchwefel);
            this.groupBox2.Controls.Add(this.radioDeJong2);
            this.groupBox2.Controls.Add(this.radioDeJong1);
            this.groupBox2.Location = new System.Drawing.Point(142, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(102, 86);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Test";
            // 
            // radioSchwefel
            // 
            this.radioSchwefel.AutoSize = true;
            this.radioSchwefel.Checked = true;
            this.radioSchwefel.Location = new System.Drawing.Point(4, 65);
            this.radioSchwefel.Name = "radioSchwefel";
            this.radioSchwefel.Size = new System.Drawing.Size(69, 17);
            this.radioSchwefel.TabIndex = 2;
            this.radioSchwefel.TabStop = true;
            this.radioSchwefel.Text = "Schwefel";
            this.radioSchwefel.UseVisualStyleBackColor = true;
            // 
            // radioDeJong2
            // 
            this.radioDeJong2.AutoSize = true;
            this.radioDeJong2.Location = new System.Drawing.Point(4, 42);
            this.radioDeJong2.Name = "radioDeJong2";
            this.radioDeJong2.Size = new System.Drawing.Size(72, 17);
            this.radioDeJong2.TabIndex = 1;
            this.radioDeJong2.Text = "de Jong 2";
            this.radioDeJong2.UseVisualStyleBackColor = true;
            // 
            // radioDeJong1
            // 
            this.radioDeJong1.AutoSize = true;
            this.radioDeJong1.Location = new System.Drawing.Point(4, 19);
            this.radioDeJong1.Name = "radioDeJong1";
            this.radioDeJong1.Size = new System.Drawing.Size(72, 17);
            this.radioDeJong1.TabIndex = 0;
            this.radioDeJong1.Text = "de Jong 1";
            this.radioDeJong1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 26);
            this.label3.TabIndex = 9;
            this.label3.Text = "No of D";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // intNoOfD
            // 
            this.intNoOfD.Location = new System.Drawing.Point(142, 95);
            this.intNoOfD.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.intNoOfD.Name = "intNoOfD";
            this.intNoOfD.Size = new System.Drawing.Size(102, 20);
            this.intNoOfD.TabIndex = 0;
            this.intNoOfD.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Cursor = System.Windows.Forms.Cursors.SizeNS;
            this.label4.Location = new System.Drawing.Point(3, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 26);
            this.label4.TabIndex = 10;
            this.label4.Text = "Max pocet gene - Gmax";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // intNP
            // 
            this.intNP.Location = new System.Drawing.Point(142, 147);
            this.intNP.Name = "intNP";
            this.intNP.Size = new System.Drawing.Size(102, 20);
            this.intNP.TabIndex = 15;
            this.intNP.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 144);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 26);
            this.label1.TabIndex = 16;
            this.label1.Text = "velkost populacie - NP";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 170);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 26);
            this.label6.TabIndex = 18;
            this.label6.Text = "mutacna konstanta - F";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // doubleF
            // 
            this.doubleF.DecimalPlaces = 3;
            this.doubleF.Dock = System.Windows.Forms.DockStyle.Top;
            this.doubleF.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.doubleF.Location = new System.Drawing.Point(142, 173);
            this.doubleF.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.doubleF.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.doubleF.Name = "doubleF";
            this.doubleF.Size = new System.Drawing.Size(102, 20);
            this.doubleF.TabIndex = 17;
            this.doubleF.Value = new decimal(new int[] {
            6,
            0,
            0,
            65536});
            // 
            // intGmax
            // 
            this.intGmax.Location = new System.Drawing.Point(142, 121);
            this.intGmax.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.intGmax.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.intGmax.Name = "intGmax";
            this.intGmax.Size = new System.Drawing.Size(102, 20);
            this.intGmax.TabIndex = 20;
            this.intGmax.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // doubleCR
            // 
            this.doubleCR.DecimalPlaces = 1;
            this.doubleCR.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.doubleCR.Location = new System.Drawing.Point(142, 199);
            this.doubleCR.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.doubleCR.Name = "doubleCR";
            this.doubleCR.Size = new System.Drawing.Size(102, 20);
            this.doubleCR.TabIndex = 14;
            this.doubleCR.Value = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            // 
            // textPatch
            // 
            this.textPatch.Location = new System.Drawing.Point(142, 225);
            this.textPatch.Name = "textPatch";
            this.textPatch.Size = new System.Drawing.Size(100, 20);
            this.textPatch.TabIndex = 3;
            this.textPatch.Text = "d:\\";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 222);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 26);
            this.label2.TabIndex = 19;
            this.label2.Text = "Vysledok uloz do";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 196);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 26);
            this.label5.TabIndex = 22;
            this.label5.Text = "prah krizenia - CR";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label5.Click += new System.EventHandler(this.Label5_Click);
            // 
            // buttonVypocet
            // 
            this.buttonVypocet.Location = new System.Drawing.Point(142, 251);
            this.buttonVypocet.Name = "buttonVypocet";
            this.buttonVypocet.Size = new System.Drawing.Size(75, 23);
            this.buttonVypocet.TabIndex = 8;
            this.buttonVypocet.Text = "Vypocet";
            this.buttonVypocet.UseVisualStyleBackColor = true;
            this.buttonVypocet.Click += new System.EventHandler(this.ButtonVypocet_ClickAsync);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 321);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(272, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(55, 17);
            this.toolStripStatusLabel1.Text = "welcome";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(272, 343);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(800, 500);
            this.MinimumSize = new System.Drawing.Size(260, 350);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.intNoOfD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.intNP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.intGmax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doubleCR)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.NumericUpDown intNoOfD;
        private System.Windows.Forms.RadioButton diffEvo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioSchwefel;
        private System.Windows.Forms.RadioButton radioDeJong2;
        private System.Windows.Forms.RadioButton radioDeJong1;
        private System.Windows.Forms.Button buttonVypocet;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown doubleCR;
        private System.Windows.Forms.NumericUpDown intNP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown doubleF;
        private System.Windows.Forms.TextBox textPatch;
        private System.Windows.Forms.NumericUpDown intGmax;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
    }
}

