﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MAI
{
    public partial class Form1 : Form
    {
        int noOfD;
        int gMax;
        int np;
        double f;
        double cr;

        string patch;
        public Form1()
        {
            InitializeComponent();
            getValues();
        }

        public static byte[] SerializeToBytes<T>(T item)
        {
            var formatter = new BinaryFormatter();
            using (var stream = new MemoryStream())
            {
                formatter.Serialize(stream, item);
                stream.Seek(0, SeekOrigin.Begin);
                return stream.ToArray();
            }
        }
        public static string DeserializeFromBytes(byte[] bytes)
        {
            var formatter = new BinaryFormatter();
            using (var stream = new MemoryStream(bytes))
            {
                return (string)formatter.Deserialize(stream);
            }
        }
        private void getValues()
        {
            noOfD = (int)intNoOfD.Value;
            gMax = (int)intGmax.Value;
            np = (int)intNP.Value;
            f = (double)doubleF.Value;
            cr = (double)doubleCR.Value;
            patch = textPatch.Text;
        }

        private void TableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void SplitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void SplitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        private void Button1_Click(object sender, EventArgs e)
        {
        }
        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private async void ButtonVypocet_ClickAsync(object sender, EventArgs e)
        {
            var checkedRadio = new[] { groupBox1 }
                    .SelectMany(g => g.Controls.OfType<RadioButton>()
                                             .Where(r => r.Checked));
            string search = "";
            string test = "";
            foreach (var c in checkedRadio)
            {
                search = c.Name;
            }
            checkedRadio = new[] { groupBox2 }
                  .SelectMany(g => g.Controls.OfType<RadioButton>()
                                           .Where(r => r.Checked));
            foreach (var c in checkedRadio)
            {
                test = c.Name;
            }
            toolStripStatusLabel1.Text = "calculating...";
            getValues();
            var progress = new Progress<string>(s => toolStripStatusLabel1.Text = s);
            await Task.Factory.StartNew(() => SecondThreadConcern.LongWork(progress, 
                noOfD, gMax, np, f, cr,
                search, test, patch),
            TaskCreationOptions.LongRunning);
          //  toolStripStatusLabel1.Text = "completed";
        }

        private void NumericNoOfDimensions_ValueChanged(object sender, EventArgs e)
        {

        }

        private void TableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void radioRandom_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
    class SecondThreadConcern
    {

        public static void LongWork(IProgress<string> progress, int noOfD,
            int gMax, int np, double f, double cr,
            string search, string test, string patch)
        {
            // Perform a long running work...
            progress.Report("calculating...." +
                "");
            Search rs = new Search(noOfD, gMax, np, f, cr,
              search, test, patch);
            rs.rataj();
            progress.Report("calculated: "+rs.calcTime().ToString());
        }
    }
}
