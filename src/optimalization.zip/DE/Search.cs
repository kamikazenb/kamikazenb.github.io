﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
using System.Collections.Concurrent;

namespace MAI
{
    class Search
    {
        List<List<double>> zapisDoCSV = new List<List<double>>();
        List<List<double>> zapisDoCSVWorst = new List<List<double>>();
        string search;
        string test;
        Random random = new Random();
        Test testFunction;
        int overall = 0;
        string patch;
        DateTime start;

        int noOfD;
        int gMax;
        int np;
        double f;
        double cr;
        double speciman;

        public Search(int noOfD, int gMax, int np, double f, double cr, 
            string Search, string Test, string Patch)
        {
            this.noOfD = noOfD;
            this.gMax = gMax;
            this.np = np;
            this.f = f;
            this.cr = cr;
            search = Search;
            test = Test;      
            patch = Patch;
            start = DateTime.UtcNow;
        }
        public void rataj()
        {
            testFunction = new Test(test);

            for (int i = 0; i < 30; i++)
            {
                switch (search)
                {
                    case "diffEvo":
                        DiffEvo();
                        break;    
                    default:
                        break;
                }
                overall++;
            }

        }
        public void DiffEvo()
        {
            List<double> jedinec;
            SortedList<double, List<double>> onePopulation = new SortedList<double, List<double>>(); 
            List<SortedList<double, List<double>>> allPopulations = new List<SortedList<double, List<double>>>();
             speciman = testFunction.getSpeciman();
            //generate random population 
            for(int i = 0; i<np; i++)
            {
                jedinec = new List<double>();
                for (int j = 0; j<noOfD; j++)
                {
                    jedinec.Add(randomDouble(speciman*(-1), speciman));
                }
                double ohodnotenie = testFunction.ohodnot(jedinec);
                onePopulation.Add(ohodnotenie, jedinec);
            }
            allPopulations.Add(onePopulation);

            HashSet<List<double>> jedinci ;

            /*
             * Gmax = max pocet generacii
             * NP = velkost populacie
             * F = mutacna konstanta
             * CR = prah krizenia
             */
            int count = 0;
            //generacne koliecko
            while (gMax > count)
            {
                count++;
                SortedList<double, List<double>>  previousPopulation = allPopulations.ElementAt(allPopulations.Count-1);
                SortedList<double, List<double>> newPopulation = new SortedList<double, List<double>>();
                //pre kazdeho noveho jedinca v populacii
                for (int i = 0; i < np; i++)
                {
                    jedinci =  new HashSet<List<double>>();
                    //pridaj zakladne x 
                    jedinci.Add(previousPopulation.ElementAt(i).Value);
                    //pridaj nahodnych jedincov
                    int body = 3;
                    while(body > 0)
                    {
                        int randomPrvok = randomInt(0, np);
                        List<double> actual = previousPopulation.ElementAt(randomPrvok).Value;
                         if (!jedinci.Contains(actual))
                        {
                            jedinci.Add(actual);
                            body--;
                        }
                        else
                        {
                            int b = 0;
                        }
                    }

                    //vypocet mutanta
                    List<double> mutant = new List<double>();
                    for(int dimenzia = 0; dimenzia<noOfD; dimenzia++)
                    {
                        double xr1 = jedinci.ElementAt(1).ElementAt(dimenzia);
                        double xr2 = jedinci.ElementAt(2).ElementAt(dimenzia);
                        double xr3 = jedinci.ElementAt(3).ElementAt(dimenzia);
                        double actualF = (f / gMax)*(gMax-count);
                        double hodnotaMutanta = xr1 + actualF * (xr2 - xr3);
                        //osetrenie presahu - continuus space
                        if (Math.Abs(hodnotaMutanta) > speciman) {
                            //hodnotaMutanta = randomDouble(speciman * -1, speciman);
                           
                            double rozdiel = Math.Abs(hodnotaMutanta) - speciman;
                            if (hodnotaMutanta < speciman * -1)
                            {
                                hodnotaMutanta = speciman - rozdiel;
                            }
                            else
                            {
                                hodnotaMutanta = (speciman * -1) + rozdiel;
                            }
                            
                        }
                        mutant.Add(hodnotaMutanta);
                    }

                    //krizenie
                    List<double> novyJedinec = new List<double>();
                    for(int dimenzia = 0; dimenzia<noOfD; dimenzia++)
                    {
                        double random = randomDouble(0, 1);
                        if (random <= cr)
                        {
                            novyJedinec.Add(mutant.ElementAt(dimenzia));
                        }
                        else
                        {
                            novyJedinec.Add(jedinci.ElementAt(0).ElementAt(dimenzia));
                        }

                    }

                    //ohodnotenie
                    double ohodnotenie = testFunction.ohodnot(novyJedinec);

                    //vyber jedinca ktory sa prida do novej populacie
                    if (ohodnotenie <= previousPopulation.ElementAt(i).Key)
                    {
                        bool added = false;
                        while (!added)
                        {
                            try
                            {
                                newPopulation.Add(ohodnotenie, novyJedinec);
                                added = true;
                            }
                            catch (Exception)
                            {
                                ohodnotenie += 0.0000001;                              
                            }
                        }
                       
                        
                    }
                    else
                    {
                        newPopulation.Add(previousPopulation.ElementAt(i).Key, previousPopulation.ElementAt(i).Value);
                    } 
                }
                allPopulations.Add(newPopulation);
            }

            
            List<double> good = new List<double>();
            for (int i = 0; i<allPopulations.Count; i++ )
            {            
               good.Add(allPopulations.ElementAt(i).ElementAt(0).Key);
               
               
            }
            zapisDoCSV.Add(good);
            zapis(zapisDoCSV, "result.csv");

            List<double> bad = new List<double>();
            for (int i = 0; i < allPopulations.Count; i++)
            {
                bad.Add(allPopulations.ElementAt(i).ElementAt(allPopulations.ElementAt(i).Count-1).Key);


            }
            zapisDoCSVWorst.Add(bad);
            zapis(zapisDoCSVWorst, "resultBad.csv");

        }
        public TimeSpan calcTime()
        {
            DateTime end = DateTime.UtcNow;
            TimeSpan difference = end.Subtract(start);
            return difference;
        }

        public void zapis(List<List<Double>> navrat, string fileName)
        {
            if (overall == 29)
            {
                string csvpatch = patch;
                csvpatch = csvpatch + fileName;
                StringBuilder csvcontent = new StringBuilder();
                File.WriteAllText(csvpatch, string.Empty);
                //    csvcontent.AppendLine("ECF;result");

                int longest = 0;
                for (int i = 0; i < navrat.Count; i++)
                {
                    if (navrat.ElementAt(i).Count > longest)
                    {
                        longest = navrat.ElementAt(i).Count;
                    }
                }
                string firstLine = " ;";
                for (int j = 0; j < navrat.Count; j++)
                {
                    firstLine = firstLine + j.ToString() + ";";
                }
                csvcontent.AppendLine(firstLine);
                for (int i = 0; i < longest; i++)
                {
                    string line = i.ToString() + ";";

                    foreach (var item in navrat)
                    {
                        try
                        {
                            line = line + item.ElementAt(i).ToString() + ";";
                        }
                        catch (Exception)
                        {
                            line = line + " ;";
                        }
                    }

                    csvcontent.AppendLine(line);
                }

                File.AppendAllText(csvpatch, csvcontent.ToString());
            }

        }
        public double randomDouble(double min, double max)
        {
            return random.NextDouble() * (max - min) + min;
        }
        public int randomInt(int min, int max)
        {
            return random.Next(min, max);
        }
    }


}
